package jwt.taskjwt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskJwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskJwtApplication.class, args);
	}

}
